from stable_baselines3 import PPO
from main import TradingEnv

model=PPO.load("ppo_trading_agent")

def infer(data):
    env=TradingEnv(data)
    obs=env.reset()
    action,_=model.predict(obs)
    return ["Hold","Buy","Sell"][action]
