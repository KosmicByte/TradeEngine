import numpy as np
from stable_baselines3 import PPO
from main import TradingEnv
from predict_signal_realtime import predict_trade_signal

data = [{'close':100+i,'sma':95,'atr':2} for i in range(1000)]
env = TradingEnv(data)
model = PPO.load("ppo_trading_agent")

obs = env.reset(); total_rl=0; done=False
while not done:
    action,_ = model.predict(obs)
    obs, r, done, _ = env.step(action)
    total_rl += r

pnl=0
for i in range(len(data)-1):
    sig=predict_trade_signal(data[:i+1])
    diff=data[i+1]['close']-data[i]['close']
    if sig=="Buy": pnl+=diff
    elif sig=="Sell": pnl-=diff

print("RL Reward:", total_rl, "Baseline PnL:", pnl)
