import optuna
from stable_baselines3 import PPO
from main import TradingEnv

def objective(trial):
    data = [{'close':100+i,'sma':95,'atr':2} for i in range(500)]
    env = TradingEnv(data)
    lr = trial.suggest_loguniform('lr',1e-5,1e-2)
    gamma = trial.suggest_uniform('gamma',0.9,0.9999)
    model = PPO("MlpPolicy", env, learning_rate=lr, gamma=gamma, verbose=0)
    model.learn(total_timesteps=5000)
    obs=env.reset(); tot=0; done=False
    while not done:
        action,_=model.predict(obs)
        obs, r, done, _ = env.step(action); tot+=r
    return -tot

study=optuna.create_study(); study.optimize(objective, n_trials=5)
print(study.best_params)
