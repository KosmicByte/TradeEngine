import pytest
from main import TradingEnv

@pytest.fixture
def data():
    return [{'close':100,'sma':95,'atr':2} for _ in range(20)]

def test_env(data):
    env=TradingEnv(data)
    obs=env.reset()
    assert len(obs)==3
    obs, reward, done, _ = env.step(0)
    assert isinstance(reward,(int,float))
