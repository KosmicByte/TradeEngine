def compute_reward(portfolio_value, prev_value, cost=0):
    return (portfolio_value - prev_value) - cost
