from fastapi import FastAPI, HTTPException
import requests
from bs4 import BeautifulSoup
app=FastAPI()

@app.get("/news-sentiment")
def news_sentiment(max_headlines: int = 20):
    r=requests.get("https://finviz.com/news.ashx", headers={"User-Agent":"Mozilla/5.0"})
    soup=BeautifulSoup(r.text,"html.parser")
    lines=[a.text for a in soup.select("table.fullview-news-outer td>a")][:max_headlines]
    pos=neg=0
    for l in lines:
        if any(w in l.lower() for w in ["beats","surges"]): pos+=1
        if any(w in l.lower() for w in ["misses","drops"]): neg+=1
    total=len(lines)
    score=(pos-neg)/total if total else 0
    return {"sentiment_score":round(score,3),"positive":pos,"negative":neg,"total":total}
