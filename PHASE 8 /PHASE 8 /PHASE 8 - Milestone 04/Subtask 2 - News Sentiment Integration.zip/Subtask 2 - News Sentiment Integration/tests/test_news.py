import pytest
from fastapi.testclient import TestClient
from main import app
client=TestClient(app)
def test_news(monkeypatch):
    html="<table class='fullview-news-outer'><tr><td><a>stock surges</a></td></tr></table>"
    monkeypatch.setattr("requests.get", lambda *args,**kwargs: type("R",(),{"text":html}))
    res=client.get("/news-sentiment?max_headlines=1")
    assert res.status_code==200
    assert res.json()["positive"]==1
