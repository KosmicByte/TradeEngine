import pytest
from fastapi.testclient import TestClient
from main import app
client=TestClient(app)
def test_satellite():
    res=client.get("/satellite-index?area=Test")
    assert res.status_code==200
    assert "ndvi" in res.json()
