from fastapi import FastAPI, Query
import random
app=FastAPI()

@app.get("/satellite-index")
def satellite_index(area: str = Query(...)):
    return {"area":area,"ndvi":round(random.uniform(0,1),3)}
