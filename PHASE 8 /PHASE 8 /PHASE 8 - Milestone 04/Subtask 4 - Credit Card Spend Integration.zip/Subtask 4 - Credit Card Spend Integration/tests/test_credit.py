import pytest
from fastapi.testclient import TestClient
from main import app
client=TestClient(app)
def test_credit():
    content="amount
100
200"
    res=client.post("/credit-spend",files={"file":("a.csv",content,"text/csv")})
    assert res.status_code==200
    assert res.json()["total_spend"]==300
