from fastapi import FastAPI, File, UploadFile
import pandas as pd
import io
app=FastAPI()

@app.post("/credit-spend")
async def credit_spend(file: UploadFile = File(...)):
    df=pd.read_csv(io.StringIO((await file.read()).decode()))
    total=df["amount"].sum() if "amount" in df.columns else 0
    return {"total_spend": total, "records": len(df)}
