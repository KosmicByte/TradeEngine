from fastapi import FastAPI, HTTPException, Query
import os
import tweepy
from textblob import TextBlob
app = FastAPI()

BEARER_TOKEN = os.getenv("TWITTER_BEARER_TOKEN","")
client = tweepy.Client(bearer_token=BEARER_TOKEN)

@app.get("/social-sentiment")
def social_sentiment(query: str = Query(...), max_tweets: int = 100):
    tweets = client.search_recent_tweets(query, max_results=min(max_tweets,100))
    scores=[]; pos=neu=neg=0
    for t in (tweets.data or []):
        p=TextBlob(t.text).sentiment.polarity
        scores.append(p)
        if p>0.05: pos+=1
        elif p< -0.05: neg+=1
        else: neu+=1
    avg=sum(scores)/len(scores) if scores else 0
    return {"sentiment_score": round(avg,3),"positive":pos,"neutral":neu,"negative":neg}
