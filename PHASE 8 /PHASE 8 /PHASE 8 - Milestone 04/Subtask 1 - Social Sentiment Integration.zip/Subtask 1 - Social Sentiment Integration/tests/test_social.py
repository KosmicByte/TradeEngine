import pytest
from fastapi.testclient import TestClient
from main import app
client=TestClient(app)
def test_social(monkeypatch):
    class Fake: data=[type("T",(),{"text":"good"})]
    monkeypatch.setattr("main.client.search_recent_tweets", lambda q,max_results: Fake())
    res=client.get("/social-sentiment?query=test&max_tweets=1")
    assert res.status_code==200
    assert res.json()["positive"]==1
