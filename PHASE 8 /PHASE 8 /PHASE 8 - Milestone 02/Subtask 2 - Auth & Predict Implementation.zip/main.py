
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os
import requests

# Security scheme
bearer_scheme = HTTPBearer()

# Config
AI_SERVICE_URL = os.environ.get("AI_SERVICE_URL", "http://localhost:8001/predict")
API_KEY = os.environ.get("API_KEY", "mysecretapikey")  # For demo, use env var

app = FastAPI(
    title="Trading System API with Auth",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

class FeatureRequest(BaseModel):
    features: list[list[float]]

class PredictResponse(BaseModel):
    prediction: str
    confidence: float

def validate_api_key(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    token = credentials.credentials
    if token != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )

@app.post("/predict", response_model=PredictResponse, dependencies=[Depends(validate_api_key)])
def predict(req: FeatureRequest):
    # Forward request to AI service
    try:
        resp = requests.post(AI_SERVICE_URL, json={"data": req.features}, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        return {
            "prediction": data.get("prediction", "Hold"),
            "confidence": data.get("confidence", 1.0)
        }
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"AI service error: {e}")

@app.get("/health")
def health():
    return {"status": "ok", "auth": "enabled"}
