import os
import pytest
from fastapi.testclient import TestClient
from main import app, API_KEY

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["auth"] == "enabled"

def test_predict_without_auth():
    res = client.post("/predict", json={"features": [[0]*12]})
    assert res.status_code == 401

@pytest.fixture(autouse=True)
def stub_ai_service(monkeypatch):
    def fake_post(url, json, timeout):
        class R:
            status_code = 200
            def raise_for_status(self): pass
            def json(self): return {"prediction": "Buy", "confidence": 0.75}
        return R()
    monkeypatch.setenv("API_KEY", API_KEY)
    monkeypatch.setenv("AI_SERVICE_URL", "http://fake")
    monkeypatch.setattr("requests.post", fake_post)

def test_predict_with_auth():
    headers = {"Authorization": f"Bearer {API_KEY}"}
    res = client.post("/predict", headers=headers, json={"features": [[0]*12]})
    assert res.status_code == 200
    data = res.json()
    assert data["prediction"] == "Buy"
    assert data["confidence"] == 0.75