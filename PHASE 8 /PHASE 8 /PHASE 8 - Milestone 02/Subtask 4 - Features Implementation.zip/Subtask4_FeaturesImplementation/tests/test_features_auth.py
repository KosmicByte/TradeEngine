import pytest
from fastapi.testclient import TestClient
import os
from main import app, API_KEY

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200

def test_features_unauthorized():
    res = client.get("/features/latest")
    assert res.status_code == 401

@pytest.fixture(autouse=True)
def stub_feature_service(monkeypatch):
    def fake_get(url, timeout):
        class R:
            status_code = 200
            def raise_for_status(self): pass
            def json(self): return {"sma":100,"atr":10}
        return R()
    monkeypatch.setenv("API_KEY", API_KEY)
    monkeypatch.setenv("FEATURE_SERVICE_URL", "http://fake")
    import requests
    monkeypatch.setattr(requests, "get", fake_get)

def test_features_with_auth():
    headers = {"Authorization": f"Bearer {API_KEY}"}
    res = client.get("/features/latest", headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert "sma" in data and "atr" in data
