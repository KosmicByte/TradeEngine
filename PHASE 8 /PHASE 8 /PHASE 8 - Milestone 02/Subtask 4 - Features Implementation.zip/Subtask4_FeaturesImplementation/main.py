from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import os
import requests

bearer_scheme = HTTPBearer()
API_KEY = os.environ.get("API_KEY", "mysecretapikey")
FEATURE_SERVICE_URL = os.environ.get("FEATURE_SERVICE_URL", "http://localhost:8003/features/latest")

def validate_api_key(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    if credentials.credentials != API_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")

app = FastAPI(title="Features API with Auth")

@app.get("/features/latest", dependencies=[Depends(validate_api_key)])
def get_features():
    try:
        resp = requests.get(FEATURE_SERVICE_URL, timeout=5)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Feature service error: {e}")

@app.get("/health")
def health():
    return {"status": "ok", "features": "enabled"}
