from fastapi import FastAPI, HTTPException, Depends
from sqlmodel import SQLModel, Field, Session, create_engine, select
import os

# Database setup
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./auth_service.db")
engine = create_engine(DATABASE_URL, echo=True)

# Models
class Tenant(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    domain: str
    created_at: str

# Create DB
def init_db():
    SQLModel.metadata.create_all(engine)

# App
app = FastAPI(title="Auth Service")

@app.on_event("startup")
def on_startup():
    init_db()

@app.post("/tenants", response_model=Tenant)
def create_tenant(name: str, domain: str, session: Session = Depends(lambda: Session(engine))):
    # Check exists
    statement = select(Tenant).where(Tenant.name == name)
    existing = session.exec(statement).first()
    if existing:
        raise HTTPException(status_code=400, detail="Tenant already exists")
    tenant = Tenant(name=name, domain=domain, created_at=datetime.utcnow().isoformat())
    session.add(tenant)
    session.commit()
    session.refresh(tenant)
    return tenant
