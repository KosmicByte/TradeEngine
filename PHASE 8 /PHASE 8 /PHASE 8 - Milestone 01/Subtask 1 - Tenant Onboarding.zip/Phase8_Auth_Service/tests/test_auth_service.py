import pytest
from fastapi.testclient import TestClient
from main import app, init_db, engine, Tenant

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db(tmp_path):
    # override DB to use temp file
    test_db = tmp_path / "test.db"
    os.environ["DATABASE_URL"] = f"sqlite:///{test_db}"
    init_db()
    yield
    # cleanup handled by tmp_path fixture

def test_create_tenant():
    response = client.post("/tenants", json={"name":"tenant1","domain":"example.com"})
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "tenant1"
    assert data["domain"] == "example.com"

def test_create_duplicate_tenant():
    client.post("/tenants", json={"name":"tenant1","domain":"example.com"})
    response = client.post("/tenants", json={"name":"tenant1","domain":"example.com"})
    assert response.status_code == 400
    assert response.json()["detail"] == "Tenant already exists"
