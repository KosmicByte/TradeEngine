import os
import pytest
from fastapi.testclient import TestClient
from main import app, init_db, engine, Tenant, User
from sqlmodel import Session

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db(tmp_path, monkeypatch):
    test_db = tmp_path / "test.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{test_db}")
    # re-import engine with new env
    from main import engine as eng
    init_db()
    yield

def test_tenant_and_user_crud():
    # Create tenant
    response = client.post("/tenants", json={"name":"tenantA","domain":"example.com"})
    assert response.status_code == 200
    tenant = response.json()
    tid = tenant["id"]

    # Create user
    resp = client.post(f"/tenants/{tid}/users", json={"username":"user1","email":"u1@example.com","role":"Trader"})
    assert resp.status_code == 200
    user = resp.json()
    assert user["username"] == "user1"
    uid = user["id"]

    # List users
    resp = client.get(f"/tenants/{tid}/users")
    assert resp.status_code == 200
    users = resp.json()
    assert len(users) == 1

    # Get user
    resp = client.get(f"/tenants/{tid}/users/{uid}")
    assert resp.status_code == 200
    assert resp.json()["email"] == "u1@example.com"

    # Update user
    resp = client.put(f"/tenants/{tid}/users/{uid}", json={"role":"Viewer"})
    assert resp.status_code == 200
    assert resp.json()["role"] == "Viewer"

    # Delete user
    resp = client.delete(f"/tenants/{tid}/users/{uid}")
    assert resp.status_code == 200
    assert resp.json()["ok"] == True

    # Ensure deletion
    resp = client.get(f"/tenants/{tid}/users/{uid}")
    assert resp.status_code == 404
