from datetime import datetime
from typing import List
from fastapi import FastAPI, HTTPException, Depends
from sqlmodel import SQLModel, Field, Session, create_engine, select
import os

# Database setup
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./auth_service.db")
engine = create_engine(DATABASE_URL, echo=False)

# Models
class Tenant(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    domain: str
    created_at: str

class User(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    tenant_id: int = Field(foreign_key="tenant.id", index=True)
    username: str = Field(index=True)
    email: str = Field(unique=True, index=True)
    role: str
    created_at: str

# Create DB
def init_db():
    SQLModel.metadata.create_all(engine)

# Dependency
def get_session():
    with Session(engine) as session:
        yield session

# App
app = FastAPI(title="Auth Service")

@app.on_event("startup")
def on_startup():
    init_db()

# Tenant endpoints
@app.post("/tenants", response_model=Tenant)
def create_tenant(name: str, domain: str, session: Session = Depends(get_session)):
    statement = select(Tenant).where(Tenant.name == name)
    existing = session.exec(statement).first()
    if existing:
        raise HTTPException(status_code=400, detail="Tenant already exists")
    tenant = Tenant(name=name, domain=domain, created_at=datetime.utcnow().isoformat())
    session.add(tenant)
    session.commit()
    session.refresh(tenant)
    return tenant

# User management endpoints
@app.post("/tenants/{tenant_id}/users", response_model=User)
def create_user(tenant_id: int, username: str, email: str, role: str, session: Session = Depends(get_session)):
    # Check tenant exists
    statement = select(Tenant).where(Tenant.id == tenant_id)
    tenant = session.exec(statement).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    # Create user
    user = User(tenant_id=tenant_id, username=username, email=email, role=role, created_at=datetime.utcnow().isoformat())
    session.add(user)
    session.commit()
    session.refresh(user)
    return user

@app.get("/tenants/{tenant_id}/users", response_model=List[User])
def list_users(tenant_id: int, session: Session = Depends(get_session)):
    statement = select(User).where(User.tenant_id == tenant_id)
    users = session.exec(statement).all()
    return users

@app.get("/tenants/{tenant_id}/users/{user_id}", response_model=User)
def get_user(tenant_id: int, user_id: int, session: Session = Depends(get_session)):
    statement = select(User).where(User.tenant_id == tenant_id, User.id == user_id)
    user = session.exec(statement).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.put("/tenants/{tenant_id}/users/{user_id}", response_model=User)
def update_user(tenant_id: int, user_id: int, username: str = None, email: str = None, role: str = None, session: Session = Depends(get_session)):
    statement = select(User).where(User.tenant_id == tenant_id, User.id == user_id)
    user = session.exec(statement).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if username:
        user.username = username
    if email:
        user.email = email
    if role:
        user.role = role
    session.add(user)
    session.commit()
    session.refresh(user)
    return user

@app.delete("/tenants/{tenant_id}/users/{user_id}")
def delete_user(tenant_id: int, user_id: int, session: Session = Depends(get_session)):
    statement = select(User).where(User.tenant_id == tenant_id, User.id == user_id)
    user = session.exec(statement).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    session.delete(user)
    session.commit()
    return {"ok": True}
