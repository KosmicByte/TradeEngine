import pytest
from fastapi.testclient import TestClient
from main import app, r

client = TestClient(app)

@pytest.fixture(autouse=True)
def reset_redis():
    r.flushdb()
    yield
    r.flushdb()

def test_ingest_and_get_features():
    tick = {"timestamp":1.0,"open":100,"high":110,"low":90,"close":105,"volume":1000}
    res = client.post("/ticks", json=tick)
    assert res.status_code == 200
    # Now get features
    res2 = client.get("/features/latest")
    assert res2.status_code == 200
    data = res2.json()
    assert "sma" in data and "atr" in data

def test_replay():
    ticks = [{"timestamp":i,"open":100+i,"high":110+i,"low":90+i,"close":105+i,"volume":1000+i} for i in range(20)]
    res = client.post("/replay", json=ticks)
    assert res.status_code == 200
    assert res.json()["count"] == 20
    # After replay, features exist
    res2 = client.get("/features/latest")
    assert res2.status_code == 200
