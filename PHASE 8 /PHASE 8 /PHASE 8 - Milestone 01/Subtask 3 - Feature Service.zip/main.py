from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import redis
import json

# Redis setup
r = redis.Redis(host="localhost", port=6379, db=1, decode_responses=True)

app = FastAPI(title="Feature Service")

class Tick(BaseModel):
    timestamp: float
    open: float
    high: float
    low: float
    close: float
    volume: float

# Ingest tick and update feature store
@app.post("/ticks")
def ingest_tick(tick: Tick):
    window = json.loads(r.get("ohlcv_window") or "[]")
    window.append(tick.dict())
    if len(window) > 50:
        window.pop(0)
    r.set("ohlcv_window", json.dumps(window))
    # Compute simple features
    closes = [t["close"] for t in window]
    sma = sum(closes[-14:]) / len(closes[-14:]) if len(closes) >= 14 else sum(closes)/len(closes)
    highs = [t["high"] for t in window]
    lows = [t["low"] for t in window]
    atr = (max(highs[-14:]) - min(lows[-14:])) if len(window) >= 14 else (max(highs) - min(lows))
    features = {"sma": sma, "atr": atr}
    r.set("latest_features", json.dumps(features))
    return {"status": "ok", "features": features}

# Retrieve latest features
@app.get("/features/latest")
def get_latest_features():
    data = r.get("latest_features")
    if not data:
        raise HTTPException(status_code=404, detail="No features available")
    return json.loads(data)

# Backfill endpoint for replay mode
@app.post("/replay")
def replay_ticks(ticks: list[Tick]):
    r.delete("ohlcv_window")
    for tick in ticks:
        ingest_tick(tick)
    return {"status": "replayed", "count": len(ticks)}
