"""
dashboard_ui - stub for Phase8 Milestone1
"""

from fastapi import FastAPI

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "ok", "service": "dashboard_ui"}