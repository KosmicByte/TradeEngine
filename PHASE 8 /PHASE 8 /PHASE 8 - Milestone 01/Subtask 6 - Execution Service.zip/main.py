from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os

# Import ExecutionManager from execution_connector module
from execution_connector import ExecutionManager

class ExecuteRequest(BaseModel):
    symbol: str
    option_type: str
    strike: int
    expiry: str
    win_rate: float
    rr_ratio: float

app = FastAPI(title="Execution Service")

@app.post("/execute")
def execute(req: ExecuteRequest):
    try:
        # Initialize execution manager with environment credentials
        manager = ExecutionManager(
            api_key=os.environ["API_KEY"],
            access_token=os.environ["ACCESS_TOKEN"],
            secret=os.environ["API_SECRET"],
            capital=float(os.environ.get("CAPITAL", 100000))
        )
        order = manager.execute_trade(
            symbol=req.symbol,
            strike=req.strike,
            option_type=req.option_type,
            expiry=req.expiry,
            win_rate=req.win_rate,
            rr_ratio=req.rr_ratio
        )
        if order:
            return {"status": "executed", "order": order}
        else:
            raise HTTPException(status_code=500, detail="Order execution returned no order object")
    except KeyError as ke:
        raise HTTPException(status_code=500, detail=f"Missing environment variable: {str(ke)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health():
    return {"status": "ok"}
