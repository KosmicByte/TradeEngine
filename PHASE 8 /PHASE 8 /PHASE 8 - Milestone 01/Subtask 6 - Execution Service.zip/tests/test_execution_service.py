import pytest
from fastapi.testclient import TestClient
import os

# Ensure environment variables for manager
@pytest.fixture(autouse=True)
def set_env(monkeypatch):
    monkeypatch.setenv("API_KEY", "test_key")
    monkeypatch.setenv("ACCESS_TOKEN", "test_token")
    monkeypatch.setenv("API_SECRET", "test_secret")
    monkeypatch.setenv("CAPITAL", "100000")
    yield

# Fake ExecutionManager
class FakeManager:
    def __init__(self, *args, **kwargs):
        pass
    def execute_trade(self, symbol, strike, option_type, expiry, win_rate, rr_ratio):
        return {"order_id": 101, "symbol": symbol, "strike": strike}

@pytest.fixture(autouse=True)
def patch_manager(monkeypatch):
    import execution_connector
    monkeypatch.setattr(execution_connector, "ExecutionManager", FakeManager)
    yield

from main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json() == {"status": "ok"}

def test_execute_success():
    body = {
        "symbol": "NIFTY",
        "option_type": "CE",
        "strike": 17500,
        "expiry": "06JUN25",
        "win_rate": 0.6,
        "rr_ratio": 2.0
    }
    res = client.post("/execute", json=body)
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "executed"
    assert "order" in data
    assert data["order"]["order_id"] == 101
