import 'package:integration_test/integration_test.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('full app navigation and signal fetch', (WidgetTester tester) async {
    // Launch app
    app.main();
    await tester.pumpAndSettle();

    // Expect login screen
    expect(find.text('Login'), findsOneWidget);

    // Enter dummy API key and login
    await tester.enterText(find.byType(TextField), 'demokey');
    await tester.tap(find.text('Login'));
    await tester.pumpAndSettle();

    // Navigate through tabs: Signal, Positions, Strategies, History, Settings
    final tabs = ['Signal', 'Positions', 'Strategies', 'History', 'Settings'];
    for (var tab in tabs) {
      await tester.tap(find.text(tab));
      await tester.pumpAndSettle();
      expect(find.text(tab == 'Signal' ? 'Latest Signal:' : tab), findsWidgets);
    }
  });
