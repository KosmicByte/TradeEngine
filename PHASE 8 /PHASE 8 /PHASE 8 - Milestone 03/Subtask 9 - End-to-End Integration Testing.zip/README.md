# Subtask 9: End-to-End & Integration Testing

This subtask adds integration tests to exercise the full mobile app flow:

- `integration_test/app_test.dart`: Launches app, performs login, and navigates through all screens.
- `test_driver/integration_test.dart`: Driver for integration_test package.
- CI workflow `.github/workflows/flutter_integration_ci.yml` to run integration tests on GitHub Actions.
- Updated `pubspec.yaml` to include `integration_test` dependency.

## Running Integration Tests Locally
```
flutter drive   --driver=test_driver/integration_test.dart   --target=integration_test/app_test.dart
```
