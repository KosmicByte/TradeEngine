import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(TradingCompanionApp());
}

class TradingCompanionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trading Companion',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String signal = 'Unknown';

  Future<void> fetchSignal() async {
    final response = await http.post(
      Uri.parse('https://api.yoursaas.com/v1/predict'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'features': []}), // TODO: supply real features
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        signal = data['prediction'];
      });
    } else {
      setState(() {
        signal = 'Error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Trading Companion'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Latest Signal:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text(signal, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: fetchSignal,
              child: Text('Refresh Signal'),
            ),
          ],
        ),
      ),
    );
  }
}
