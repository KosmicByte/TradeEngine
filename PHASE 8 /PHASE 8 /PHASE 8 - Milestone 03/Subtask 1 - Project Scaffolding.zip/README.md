# Subtask 1: Project Scaffolding

This Flutter project serves as the mobile companion for the Ultimate Trading System.

## Structure

- `pubspec.yaml`: project dependencies
- `lib/main.dart`: entry point
- `.github/workflows/flutter_ci.yml`: CI for analyze & test
- `test/widget_test.dart`: sample test

## Getting Started

1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Run `flutter pub get`
3. Open in IDE (VSCode/Android Studio)
4. Run on emulator: `flutter run`
