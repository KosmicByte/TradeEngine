import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart';

void main() {
  testWidgets('App loads and displays title', (WidgetTester tester) async {
    await tester.pumpWidget(TradingCompanionApp());
    expect(find.text('Trading Companion'), findsOneWidget);
  });
}
