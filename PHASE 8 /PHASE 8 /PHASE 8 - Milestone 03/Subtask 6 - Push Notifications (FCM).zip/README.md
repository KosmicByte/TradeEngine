# Subtask 6: Push Notifications (FCM)

This subtask integrates Firebase Cloud Messaging:

- `lib/notification_service.dart`: initializes FCM, handles tokens and messages.
- `lib/main.dart`: updated to call `NotificationService.init()`.
- `test/notification_service_test.dart`: ensures init doesn't fail.
- CI workflow in `.github/workflows/flutter_notif_ci.yml`.
