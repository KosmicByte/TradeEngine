import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/notification_service.dart';

void main() {
  test('NotificationService init does not throw', () async {
    await NotificationService.init();
    // can't assert on FCM, but initialization should complete
    expect(true, true);
  });
}
