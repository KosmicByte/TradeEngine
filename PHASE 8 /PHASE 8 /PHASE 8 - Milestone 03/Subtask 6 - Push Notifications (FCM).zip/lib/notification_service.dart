import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

class NotificationService {
  static FirebaseMessaging messaging = FirebaseMessaging.instance;

  static Future<void> init() async {
    // Initialize Firebase
    await Firebase.initializeApp();
    // Request permission
    NotificationSettings settings = await messaging.requestPermission();
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    }
    // Get token
    String? token = await messaging.getToken();
    print('FCM Token: $token');
    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        print('Foreground message: ${message.notification!.title}');
      }
    });
    // Handle background messages
    FirebaseMessaging.onMessageOpenedApp((RemoteMessage message) {
      print('Message clicked!');
    });
  }
}
