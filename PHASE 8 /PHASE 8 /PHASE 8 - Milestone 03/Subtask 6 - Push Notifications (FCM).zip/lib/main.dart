import 'package:flutter/material.dart';
import 'notification_service.dart';
import 'login_page.dart';
import 'auth_service.dart';
import 'signal_screen.dart';
import 'position_screen.dart';
import 'strategy_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  runApp(TradingCompanionApp());
}

class TradingCompanionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trading Companion',
      home: AppNavigator(),
    );
  }
}

class AppNavigator extends StatefulWidget {
  @override
  _AppNavigatorState createState() => _AppNavigatorState();
}

class _AppNavigatorState extends State<AppNavigator> {
  final AuthService _auth = AuthService();
  String? _apiKey;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _auth.getApiKey().then((key) {
      setState(() { _apiKey = key; _initialized = true; });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      return Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_apiKey == null) {
      return LoginPage(onLoginSuccess: () => setState(() => _apiKey = 'set'));
    }
    return MainScreen();
  }
}

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    SignalScreen(),
    PositionScreen(),
    StrategyScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() { _selectedIndex = index; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Trading Companion')),
      body: _widgetOptions[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Signal'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Positions'),
          BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'Strategies'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
