import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart';

void main() {
  testWidgets('SettingsScreen loads and contains Save Settings button', (WidgetTester tester) async {
    await tester.pumpWidget(TradingCompanionApp());
    // After login simulated, we assume direct
    // Navigate to Settings
    await tester.tap(find.text('Settings'));
    await tester.pump();
    expect(find.text('Save Settings'), findsOneWidget);
  });
}
