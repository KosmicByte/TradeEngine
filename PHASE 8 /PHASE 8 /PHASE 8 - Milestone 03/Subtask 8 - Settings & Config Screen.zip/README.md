# Subtask 8: Settings & Config Screen

Adds SettingsScreen to configure:
- API Base URL
- Min RR threshold
- Enable/Disable notifications

Includes:
- lib/settings_screen.dart
- lib/main.dart updated with SettingsTab
- test/settings_screen_test.dart
- CI workflow .github/workflows/flutter_settings_ci.yml
