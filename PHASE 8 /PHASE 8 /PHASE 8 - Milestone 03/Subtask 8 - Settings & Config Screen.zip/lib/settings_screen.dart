import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _apiController = TextEditingController();
  double _riskSlider = 2.0;
  bool _notifications = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _apiController.text = prefs.getString('api_url') ?? 'https://api.yoursaas.com/v1';
    _riskSlider = prefs.getDouble('risk_threshold') ?? 2.0;
    _notifications = prefs.getBool('enable_notifications') ?? true;
    setState(() {});
  }

  void _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_url', _apiController.text);
    await prefs.setDouble('risk_threshold', _riskSlider);
    await prefs.setBool('enable_notifications', _notifications);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Settings saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _apiController,
              decoration: InputDecoration(labelText: 'API Base URL'),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text('Min RR Threshold: ${_riskSlider.toStringAsFixed(1)}'),
              ],
            ),
            Slider(
              min: 1.0,
              max: 5.0,
              divisions: 8,
              value: _riskSlider,
              onChanged: (v) => setState(() => _riskSlider = v),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Enable Notifications'),
                Switch(
                  value: _notifications,
                  onChanged: (v) => setState(() => _notifications = v),
                )
              ],
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _saveSettings,
              child: Text('Save Settings'),
            ),
          ],
        ),
      ),
    );
  }
}
