#!/bin/bash
# Build and deploy script

echo "Building Android APK..."
flutter build apk --release

echo "Building iOS..."
flutter build ios --release --no-codesign

echo "Running Fastlane for iOS..."
cd fastlane
fastlane build_ios
cd ..

echo "Running Fastlane for Android..."
cd fastlane
fastlane build_android
