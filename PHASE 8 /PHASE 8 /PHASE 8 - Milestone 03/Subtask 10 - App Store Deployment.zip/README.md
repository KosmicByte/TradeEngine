# Subtask 10: App Store / Play Store Deployment

This subtask prepares the mobile companion app for distribution on Apple TestFlight and Google Play.

## Contents

- fastlane/: Fastlane configuration for iOS and Android
- build_and_deploy.sh: Script to build Flutter app and invoke Fastlane
- .github/workflows/flutter_deploy.yml: GitHub Actions for CI/CD build & deploy
- icons/icon.png: Placeholder for your app icon
- README.md: This overview

## Usage

1. Replace placeholders in fastlane/Appfile with your Apple ID and app identifier.
2. Place your app icons in icons/.
3. Ensure you have Fastlane and necessary credentials configured.
4. Run locally:
   ```
   ./build_and_deploy.sh
   ```
5. On GitHub, push to main to trigger CI/CD deploy.
