import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart';

void main() {
  testWidgets('StrategyScreen button and title appear', (WidgetTester tester) async {
    await tester.pumpWidget(TradingCompanionApp());
    // Switch to Strategies tab
    await tester.tap(find.text('Strategies'));
    await tester.pump();
    expect(find.text('Strategy Explorer'), findsOneWidget);
    expect(find.text('Get Strategies'), findsOneWidget);
  });
}
