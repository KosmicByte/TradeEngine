import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'auth_service.dart';

class StrategyScreen extends StatefulWidget {
  const StrategyScreen({Key? key}) : super(key: key);

  @override
  _StrategyScreenState createState() => _StrategyScreenState();
}

class _StrategyScreenState extends State<StrategyScreen> {
  List strategies = [];
  bool _loading = false;
  String _error = '';
  final AuthService _auth = AuthService();

  Future<void> _fetchStrategies() async {
    setState(() { _loading = true; _error = ''; });
    try {
      String? apiKey = await _auth.getApiKey();
      if (apiKey == null) throw 'No API Key';
      final response = await http.post(
        Uri.parse('https://api.yoursaas.com/v1/strategies'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer \$apiKey'
        },
        body: jsonEncode({
          'signal': 'Buy',
          'bias': 'Bullish',
          'symbol': 'NIFTY',
          'index': true
        }),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() { strategies = data['strategies']; });
      } else {
        setState(() { _error = 'Error: \${response.statusCode}'; });
      }
    } catch (e) {
      setState(() { _error = 'Failed to fetch strategies'; });
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Strategy Explorer')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _loading ? null : _fetchStrategies,
              child: Text(_loading ? 'Loading...' : 'Get Strategies'),
            ),
            SizedBox(height: 16),
            if (_error.isNotEmpty)
              Text(_error, style: TextStyle(color: Colors.red)),
            Expanded(
              child: ListView.builder(
                itemCount: strategies.length,
                itemBuilder: (context, index) {
                  final strat = strategies[index];
                  return Card(
                    child: ExpansionTile(
                      title: Text(strat['strategy']),
                      children: (strat['legs'] as List).map((leg) {
                        return ListTile(
                          title: Text('\${leg['type']} @ \${leg['strike']}'),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
