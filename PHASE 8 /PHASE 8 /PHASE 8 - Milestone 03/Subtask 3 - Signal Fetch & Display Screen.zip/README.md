# Subtask 3: Signal Fetch & Display Screen

This subtask implements the SignalScreen Flutter page to fetch and display the latest trade signal.

- `lib/signal_screen.dart`: UI and logic to call the /predict API.
- `lib/main.dart`: Launches the SignalScreen.
- `test/signal_screen_test.dart`: Widget test.
- CI workflow in `.github/workflows/flutter_signal_ci.yml`.
