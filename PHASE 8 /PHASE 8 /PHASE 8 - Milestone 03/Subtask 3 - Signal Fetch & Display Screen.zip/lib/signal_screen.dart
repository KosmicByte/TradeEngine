import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SignalScreen extends StatefulWidget {
  const SignalScreen({Key? key}) : super(key: key);

  @override
  _SignalScreenState createState() => _SignalScreenState();
}

class _SignalScreenState extends State<SignalScreen> {
  String _signal = 'Unknown';
  double _confidence = 0.0;
  bool _loading = false;
  String _error = '';

  Future<void> _fetchSignal() async {
    setState(() {
      _loading = true;
      _error = '';
    });
    try {
      final response = await http.post(
        Uri.parse('https://api.yoursaas.com/v1/predict'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'features': []}), // TODO: replace with real features
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _signal = data['prediction'] ?? 'Unknown';
          _confidence = (data['confidence'] ?? 0).toDouble();
        });
      } else {
        setState(() {
          _error = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Failed to fetch signal';
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Latest Signal')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (_error.isNotEmpty) Text(_error, style: TextStyle(color: Colors.red)),
            Text('Signal:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            _loading
                ? CircularProgressIndicator()
                : Text(_signal, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Confidence: ${(_confidence * 100).toStringAsFixed(1)}%', style: TextStyle(fontSize: 16)),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loading ? null : _fetchSignal,
              child: Text('Refresh Signal'),
            ),
          ],
        ),
      ),
    );
  }
}
