import 'package:flutter/material.dart';
import 'signal_screen.dart';
void main() {
  runApp(MaterialApp(
    title: 'Trading Companion',
    home: SignalScreen(),
  ));
}
