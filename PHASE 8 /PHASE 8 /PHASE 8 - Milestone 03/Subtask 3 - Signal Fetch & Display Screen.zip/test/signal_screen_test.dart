import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart';

void main() {
  testWidgets('Loads signal screen with title', (WidgetTester tester) async {
    await tester.pumpWidget(MaterialApp(home: SignalScreen()));
    expect(find.text('Latest Signal'), findsOneWidget);
    expect(find.text('Refresh Signal'), findsOneWidget);
  });
}
