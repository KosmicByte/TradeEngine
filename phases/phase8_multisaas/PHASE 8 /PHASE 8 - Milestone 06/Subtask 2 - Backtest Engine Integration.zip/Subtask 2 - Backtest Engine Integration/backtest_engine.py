import pandas as pd
from strategy_payoff_visualizer import plot_option_strategy

def backtest_sample(data_csv):
    df = pd.read_csv(data_csv)
    # call existing strategy engine here
    plot_option_strategy("Sample", 
                         legs=[{"type":"Buy CE","strike":20000,"premium":100}],
                         spot_price=df["close"].iloc[-1])
