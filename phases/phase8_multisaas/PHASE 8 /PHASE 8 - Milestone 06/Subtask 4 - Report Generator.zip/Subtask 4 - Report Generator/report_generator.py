import pandas as pd
import matplotlib.pyplot as plt

def generate_report(data_csv, output_pdf):
    df = pd.read_csv(data_csv)
    df["pnl"].cumsum().plot(title="Cumulative PnL")
    plt.savefig("pnl_curve.png")
    # Placeholder for PDF assembly
