import papermill as pm

pm.execute_notebook(
   'notebooks/sample_quant_backtest.ipynb',
   'notebooks/output_anon.ipynb',
   parameters=dict(rsi=14, atr=14)
)
