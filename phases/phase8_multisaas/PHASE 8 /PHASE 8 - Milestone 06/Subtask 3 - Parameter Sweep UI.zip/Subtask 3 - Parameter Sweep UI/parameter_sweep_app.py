import streamlit as st
import pandas as pd
from backtest_engine import backtest_sample

st.title("Parameter Sweep")
rsi = st.slider("RSI Window", 5, 30, 14)
atr = st.slider("ATR Period", 5, 30, 14)
if st.button("Run Sweep"):
    # Example: run backtest_sample with parameters
    st.write(f"Running with RSI={rsi}, ATR={atr}")
    # Placeholder for actual sweep logic
