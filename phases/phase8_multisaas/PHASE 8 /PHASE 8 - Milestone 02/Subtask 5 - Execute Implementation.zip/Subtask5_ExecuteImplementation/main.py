from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os
import requests

bearer_scheme = HTTPBearer()
API_KEY = os.environ.get("API_KEY", "mysecretapikey")
EXEC_SERVICE_URL = os.environ.get("EXEC_SERVICE_URL", "http://localhost:8004/execute")

class ExecuteRequest(BaseModel):
    strategy: dict
    quantity: int

class ExecuteResponse(BaseModel):
    orderId: str
    status: str

def validate_api_key(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    if credentials.credentials != API_KEY:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")

app = FastAPI(title="Execute API with Auth")

@app.post("/execute", response_model=ExecuteResponse, dependencies=[Depends(validate_api_key)])
def execute(req: ExecuteRequest):
    try:
        resp = requests.post(EXEC_SERVICE_URL, json=req.dict(), timeout=5)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Execute service error: {e}")

@app.get("/health")
def health():
    return {"status": "ok", "execute": "enabled"}
