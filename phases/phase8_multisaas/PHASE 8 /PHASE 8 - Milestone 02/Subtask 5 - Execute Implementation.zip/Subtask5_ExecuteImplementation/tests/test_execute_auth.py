import pytest
from fastapi.testclient import TestClient
import os
from main import app, API_KEY, ExecuteRequest

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200

def test_execute_unauthorized():
    res = client.post("/execute", json={"strategy":{}, "quantity":1})
    assert res.status_code == 401

@pytest.fixture(autouse=True)
def stub_exec_service(monkeypatch):
    def fake_post(url, json, timeout):
        class R:
            status_code = 200
            def raise_for_status(self): pass
            def json(self): return {"orderId":"ORD123","status":"simulated"}
        return R()
    monkeypatch.setenv("API_KEY", API_KEY)
    monkeypatch.setenv("EXEC_SERVICE_URL", "http://fake")
    import requests
    monkeypatch.setattr(requests, "post", fake_post)

def test_execute_with_auth():
    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {"strategy": {"strategy":"Bull Call Spread","legs":[{"type":"Buy CE","strike":20000}]}, "quantity":1}
    res = client.post("/execute", headers=headers, json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["orderId"] == "ORD123"
