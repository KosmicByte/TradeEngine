import os
import pytest
from fastapi.testclient import TestClient
from main import app, API_KEY

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["auth"] == "enabled"

def test_strategy_unauthorized():
    res = client.post("/strategies", json={"signal":"Buy","bias":"Bullish","symbol":"NIFTY"})
    assert res.status_code == 401

@pytest.fixture(autouse=True)
def stub_strategy_service(monkeypatch):
    def fake_post(url, json, timeout):
        class R:
            status_code = 200
            def raise_for_status(self): pass
            def json(self): return {"strategies":[{"strategy":"Bull Call Spread","legs":[{"type":"Buy CE","strike":20000}]}]}
        return R()
    monkeypatch.setenv("API_KEY", API_KEY)
    monkeypatch.setenv("STRATEGY_SERVICE_URL", "http://fake")
    import requests
    monkeypatch.setattr(requests, "post", fake_post)

def test_strategy_with_auth():
    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {"signal":"Buy","bias":"Bullish","symbol":"NIFTY","index":True}
    res = client.post("/strategies", headers=headers, json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "strategies" in data
    assert isinstance(data["strategies"], list)
