from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os
import requests

# Security
bearer_scheme = HTTPBearer()
API_KEY = os.environ.get("API_KEY", "mysecretapikey")
STRATEGY_SERVICE_URL = os.environ.get("STRATEGY_SERVICE_URL", "http://localhost:8002/recommend")

def validate_api_key(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)):
    token = credentials.credentials
    if token != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key"
        )

# FastAPI app
app = FastAPI(title="Strategy Service with Auth")

class StrategyRequest(BaseModel):
    signal: str
    bias: str
    symbol: str
    index: bool = True

class Strategy(BaseModel):
    strategy: str
    legs: list[dict]

class StrategyResponse(BaseModel):
    strategies: list[Strategy]

@app.post("/strategies", response_model=StrategyResponse, dependencies=[Depends(validate_api_key)])
def strategies(req: StrategyRequest):
    try:
        resp = requests.post(STRATEGY_SERVICE_URL, json=req.dict(), timeout=5)
        resp.raise_for_status()
        data = resp.json()
        return {"strategies": data.get("strategies", [])}
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Strategy service error: {e}")

@app.get("/health")
def health():
    return {"status": "ok", "auth": "enabled"}    
