from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict
import uvicorn

app = FastAPI(
    title="Trading System API",
    version="1.0.0",
    openapi_url="/openapi.json",
    docs_url="/docs"
)

class FeatureRequest(BaseModel):
    features: List[List[float]]

class PredictResponse(BaseModel):
    prediction: str
    confidence: float

class StrategyRequest(BaseModel):
    signal: str
    bias: str
    symbol: str
    index: bool = True

class Strategy(BaseModel):
    strategy: str
    legs: List[Dict]

class StrategyResponse(BaseModel):
    strategies: List[Strategy]

class ExecuteRequest(BaseModel):
    strategy: Strategy
    quantity: int

class ExecuteResponse(BaseModel):
    orderId: str
    status: str

@app.post("/predict", response_model=PredictResponse)
def predict(req: FeatureRequest):
    return {"prediction": "Hold", "confidence": 0.5}

@app.post("/strategies", response_model=StrategyResponse)
def strategies(req: StrategyRequest):
    return {"strategies": []}

@app.get("/features/latest")
def get_features():
    return {}

@app.post("/execute", response_model=ExecuteResponse)
def execute(req: ExecuteRequest):
    return {"orderId": "SIM123", "status": "simulated"}

@app.get("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
