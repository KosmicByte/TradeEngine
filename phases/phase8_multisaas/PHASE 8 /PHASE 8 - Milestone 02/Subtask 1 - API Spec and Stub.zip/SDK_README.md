# SDK Generation Instructions

Use OpenAPI spec to generate client SDKs:

## Python SDK
openapi-generator-cli generate -i openapi.yaml -g python -o sdk/python

## JavaScript SDK
openapi-generator-cli generate -i openapi.yaml -g javascript -o sdk/js
