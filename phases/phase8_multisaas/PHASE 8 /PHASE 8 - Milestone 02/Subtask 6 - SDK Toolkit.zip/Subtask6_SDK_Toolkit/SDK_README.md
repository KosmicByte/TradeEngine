# SDK Generation

Use the OpenAPI spec (openapi.yaml) to generate client libraries:

## Python SDK
openapi-generator-cli generate -i openapi.yaml -g python -o sdk/python

## JavaScript SDK
openapi-generator-cli generate -i openapi.yaml -g javascript -o sdk/js

## Java SDK
openapi-generator-cli generate -i openapi.yaml -g java -o sdk/java

Place your API base URL and auth details in the generated code.
