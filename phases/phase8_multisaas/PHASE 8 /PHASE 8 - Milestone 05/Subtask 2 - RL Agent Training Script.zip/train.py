import gym
from stable_baselines3 import PPO
from main import TradingEnv

data = [{'close':100+i,'sma':95,'atr':2} for i in range(1000)]
env = TradingEnv(data)
model = PPO("MlpPolicy", env, verbose=0)
model.learn(total_timesteps=10000)
model.save("ppo_trading_agent")
