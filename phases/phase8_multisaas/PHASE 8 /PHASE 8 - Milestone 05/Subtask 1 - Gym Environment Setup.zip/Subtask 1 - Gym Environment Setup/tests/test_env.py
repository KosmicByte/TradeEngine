import pytest
from main import TradingEnv
@pytest.fixture
def data():
    return [{'close':100,'sma':95,'atr':2} for _ in range(10)]
def test_reset(data):
    env = TradingEnv(data)
    obs = env.reset()
    assert obs.shape == (3,)
def test_step(data):
    env = TradingEnv(data)
    env.reset()
    obs, r, done, _ = env.step(0)
    assert isinstance(r, (int,float))
