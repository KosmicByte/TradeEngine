import gym
from gym import spaces
import numpy as np

class TradingEnv(gym.Env):
    def __init__(self, data):
        super().__init__()
        self.data = data
        self.current_step = 0
        self.action_space = spaces.Discrete(3)
        self.observation_space = spaces.Box(low=0, high=np.inf, shape=(3,), dtype=np.float32)
        self.position = 0
        self.cash = 100000
        self.shares = 0

    def _get_obs(self):
        row = self.data[self.current_step]
        return np.array([row['close'], row['sma'], row['atr']], dtype=np.float32)

    def step(self, action):
        price = self.data[self.current_step]['close']
        if action == 1 and self.position == 0:
            self.shares = self.cash / price
            self.cash = 0
            self.position = 1
        elif action == 2 and self.position == 1:
            self.cash = self.shares * price
            self.shares = 0
            self.position = 0
        portfolio_value = self.cash + self.shares * price
        reward = portfolio_value - 100000
        self.current_step += 1
        done = self.current_step >= len(self.data)-1
        return self._get_obs(), reward, done, {}

    def reset(self):
        self.current_step = 0
        self.position = 0
        self.cash = 100000
        self.shares = 0
        return self._get_obs()
