import pandas as pd

def load_data(path):
    df=pd.read_csv(path)
    df['sma']=df['close'].rolling(14).mean()
    df['atr']=df['high']-df['low']
    return df.dropna().to_dict('records')
