import pytest
from fastapi.testclient import TestClient
from main import app
client=TestClient(app)
def test_aggregator(monkeypatch):
    monkeypatch.setattr("requests.get", lambda url: type("R",(),{"json":lambda:{"dummy":1}}))
    res=client.get("/alt-features")
    assert res.status_code==200
