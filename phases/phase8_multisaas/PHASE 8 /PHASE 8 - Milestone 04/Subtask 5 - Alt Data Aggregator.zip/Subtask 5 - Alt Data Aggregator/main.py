from fastapi import FastAPI, HTTPException
import requests
app=FastAPI()

@app.get("/alt-features")
def alt_features():
    try:
        soc=requests.get("http://localhost:8000/social-sentiment").json()
        news=requests.get("http://localhost:8001/news-sentiment").json()
        sat=requests.get("http://localhost:8002/satellite-index?area=Test").json()
        return {"social":soc,"news":news,"satellite":sat}
    except Exception as e:
        raise HTTPException(status_code=500,detail=str(e))
