provider "aws" {
  region = var.aws_region
}

module "eks_cluster" {
  source          = "terraform-aws-modules/eks/aws"
  cluster_name    = var.cluster_name
  cluster_version = "1.24"
  subnets         = var.subnet_ids
  vpc_id          = var.vpc_id
  node_groups = {
    default = {
      desired_capacity = 2
      max_capacity     = 3
      min_capacity     = 1
      instance_type    = "t3.medium"
    }
  }
}

resource "aws_elasticache_replication_group" "redis" {
  replication_group_id          = "trading-redis"
  replication_group_description = "Redis for trading system"
  node_type                     = "cache.t3.micro"
  number_cache_clusters         = 2
  automatic_failover_enabled    = true
  engine                        = "redis"
}

output "cluster_name" {
  value = module.eks_cluster.cluster_name
}

output "redis_endpoint" {
  value = aws_elasticache_replication_group.redis.primary_endpoint_address
}
