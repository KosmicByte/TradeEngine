# Subtask 9: CI/CD & Infrastructure as Code

## CI/CD
- GitHub Actions workflow in `.github/workflows/ci.yml`  
  - Installs dependencies, runs tests, builds and pushes Docker image

## Terraform (Infrastructure as Code)
- `terraform/` contains:
  - `main.tf`: EKS cluster and ElastiCache Redis
  - `variables.tf`: Input variables
  - `outputs.tf`: Outputs including kubeconfig and Redis endpoint

## Helm Chart
- `helm/trading-system`: Helm chart for deploying the trading system container

### Next Steps
1. Configure AWS credentials for Terraform  
2. Deploy EKS cluster and Redis  
3. Helm install the trading-system chart  
4. Enable GitHub Actions CI/CD by pushing to `main` branch
