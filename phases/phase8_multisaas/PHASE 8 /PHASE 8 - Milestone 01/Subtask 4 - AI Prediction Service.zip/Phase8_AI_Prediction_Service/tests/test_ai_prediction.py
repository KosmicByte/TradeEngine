import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json() == {"status": "ok"}

def test_predict():
    # Dummy data matching shape (1, 50, 12) with zeros
    data = {"data": [[ [0.0]*12 for _ in range(50) ] ]}
    res = client.post("/predict", json=data)
    assert res.status_code in (200, 500)  # 500 if model file missing
    # If 200, expect keys
    if res.status_code == 200:
        assert "prediction" in res.json()
