from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import numpy as np
import onnxruntime as ort

# Load ONNX model
model_path = os.environ.get("MODEL_PATH", "trading_model.onnx")
session = ort.InferenceSession(model_path)

class Features(BaseModel):
    data: list  # Expect list of lists for sequence data

app = FastAPI(title="AI Prediction Service")

@app.post("/predict")
def predict(features: Features):
    """
    Returns: {"prediction": "Buy"/"Sell"/"Hold"}
    """
    arr = np.array(features.data, dtype=np.float32)
    # Ensure shape (1, seq_len, input_size)
    if arr.ndim == 2:
        arr = arr[np.newaxis, ...]
    try:
        inputs = {session.get_inputs()[0].name: arr}
        outputs = session.run(None, inputs)
        pred = int(np.argmax(outputs[0], axis=1)[0])
        label = ["Buy", "Sell", "Hold"][pred]
        return {"prediction": label}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health():
    return {"status": "ok"}
