import pytest
from telemetry_service.main import app
from fastapi.testclient import TestClient

client = TestClient(app)

def test_metrics_endpoint():
    assert client.get("/metrics").status_code == 200
