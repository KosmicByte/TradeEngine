import pytest
from feature_service.main import app, r
from fastapi.testclient import TestClient

client = TestClient(app)

@pytest.fixture(autouse=True)
def reset_redis(monkeypatch):
    monkeypatch.setenv("REDIS_HOST", "localhost")
    r.flushdb()
    yield
    r.flushdb()

def test_ingest_and_retrieve():
    tick = {"timestamp":1.0,"open":100,"high":110,"low":90,"close":105,"volume":1000}
    res = client.post("/ticks", json=tick)
    assert res.status_code == 200
    res2 = client.get("/features/latest")
    assert res2.status_code == 200
