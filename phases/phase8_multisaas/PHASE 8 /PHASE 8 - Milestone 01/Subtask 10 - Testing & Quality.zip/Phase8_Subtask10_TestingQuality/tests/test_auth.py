import pytest
from tenant_onboarding_service.main import app, init_db, Session, Tenant
from fastapi.testclient import TestClient

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db(tmp_path, monkeypatch):
    db_path = tmp_path / "test.db"
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{db_path}")
    init_db()
    yield

def test_create_tenant():
    res = client.post("/tenants", json={"name": "t1", "domain": "d1"})
    assert res.status_code == 200
    assert res.json()["name"] == "t1"
