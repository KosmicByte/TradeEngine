import timeit
import numpy as np

# Benchmark ONNX inference
def benchmark_inference():
    try:
        from fast_inference_onnx import predict
        arr = np.random.rand(1, 50, 12).astype(np.float32)
        latency = timeit.timeit(lambda: predict(arr), number=100) / 100
        print(f"Average inference latency: {latency*1000:.2f} ms")
    except Exception as e:
        print("Inference benchmark failed:", e)

# Benchmark backtest throughput
def benchmark_backtest():
    try:
        from integrated_phase3_strategy_engine import smart_strategy_engine
        import pandas as pd
        df = pd.DataFrame({
            'open': np.random.rand(1000),
            'high': np.random.rand(1000),
            'low': np.random.rand(1000),
            'close': np.random.rand(1000),
            'volume': np.random.randint(100, 1000, 1000)
        })
        start = timeit.default_timer()
        smart_strategy_engine(df, symbol="NIFTY")
        duration = timeit.default_timer() - start
        print(f"Backtest execution time (per 1000 candles): {duration:.2f} sec")
    except Exception as e:
        print("Backtest benchmark failed:", e)

if __name__ == "__main__":
    benchmark_inference()
    benchmark_backtest()
