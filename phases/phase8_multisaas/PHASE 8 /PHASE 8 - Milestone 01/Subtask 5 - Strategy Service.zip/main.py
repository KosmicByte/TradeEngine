from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from option_strategy_recommender import suggest_option_strategies

class RecommendRequest(BaseModel):
    signal: str  # "Buy", "Sell", "Hold"
    bias: str    # "Bullish", "Bearish", "Neutral"
    symbol: str = "NIFTY"
    index: bool = True  # True for index chain, False for equity

app = FastAPI(title="Strategy Service")

@app.post("/recommend")
def recommend(req: RecommendRequest):
    """
    Returns a list of strategy suggestions based on signal and bias.
    """
    try:
        strategies = suggest_option_strategies(
            df=__import__('multi_asset_option_chain').multi_asset_option_chain.fetch_option_chain(
                symbol=req.symbol, index=req.index),
            market_bias=req.bias
        )
        # Return top 3
        return {"strategies": strategies[:3]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health():
    return {"status": "ok", "service": "Strategy Service"}
