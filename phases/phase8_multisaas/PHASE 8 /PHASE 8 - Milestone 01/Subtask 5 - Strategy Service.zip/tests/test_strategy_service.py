import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"

def test_recommend_endpoint(monkeypatch):
    # Monkeypatch fetch_option_chain to return a small df
    import pandas as pd
    df = pd.DataFrame({
        "strikePrice": [100, 110, 120],
        "CE_OI": [1000, 800, 600],
        "PE_OI": [500, 700, 900]
    })
    def fake_fetch(symbol, index):
        return df
    monkeypatch.setattr("multi_asset_option_chain.fetch_option_chain", fake_fetch)

    req = {"signal": "Buy", "bias": "Bullish", "symbol": "NIFTY", "index": True}
    res = client.post("/recommend", json=req)
    assert res.status_code == 200
    data = res.json()
    assert "strategies" in data
    assert isinstance(data["strategies"], list)
