
import streamlit as st
import requests
import pandas as pd
from streamlit_auth_wrapper import check_password

# Authentication
if not check_password():
    st.stop()

st.set_page_config(page_title="Ultimate Trading Dashboard", layout="wide")
st.title("🚀 Ultimate Trading System - Dashboard UI (Enhanced)")

# Sidebar for navigation
st.sidebar.header("Navigation")
page = st.sidebar.radio("Go to", ["Live Signals", "Strategy Explorer", "Admin Console", "Settings"])

API_BASE = st.secrets.get("api_base_url", "http://localhost:8000")

# Live Signals Page
if page == "Live Signals":
    st.subheader("🔍 Live Signal Panel")
    if st.button("Fetch Signal"):
        # Fetch live prediction
        df = pd.read_csv("temp_latest.csv")  # or use file uploader
        features = df[['open','high','low','close','volume']].values.tolist()
        response = requests.post(f"{API_BASE}/predict", json={"data": features})
        if response.ok:
            sig = response.json().get("prediction")
            st.success(f"Signal: {sig}")
        else:
            st.error("Failed to fetch signal")

# Strategy Explorer Page
elif page == "Strategy Explorer":
    st.subheader("📊 Strategy Recommendations")
    symbol = st.selectbox("Symbol", ["NIFTY","BANKNIFTY","RELIANCE"])
    bias = st.selectbox("Bias", ["Bullish","Bearish","Neutral"])
    if st.button("Recommend Strategies"):
        payload = {"signal": "Buy", "bias": bias, "symbol": symbol, "index": symbol in ["NIFTY","BANKNIFTY"]}
        resp = requests.post(f"{API_BASE}/recommend", json=payload)
        if resp.ok:
            strategies = resp.json().get("strategies", [])
            for i, strat in enumerate(strategies, start=1):
                st.markdown(f"**Strategy {i}: {strat['strategy']}**")
                df_legs = pd.DataFrame(strat["legs"])
                st.table(df_legs)
        else:
            st.error("Failed to get strategies")

# Admin Console Page
elif page == "Admin Console":
    st.subheader("🛠 Admin Console")
    st.write("Manage tenants and users (coming soon)")
    # Placeholder for user management integration

# Settings Page
elif page == "Settings":
    st.subheader("⚙️ Settings")
    st.write("Configure API base URL and authentication settings")
    new_api = st.text_input("API Base URL", API_BASE)
    if st.button("Save Settings"):
        st.secrets["api_base_url"] = new_api
        st.success("Settings updated. Refresh to apply.")
