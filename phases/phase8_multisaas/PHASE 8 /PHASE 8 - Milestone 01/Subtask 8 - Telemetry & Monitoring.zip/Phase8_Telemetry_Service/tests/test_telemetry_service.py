import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_metrics_empty():
    res = client.get("/metrics")
    assert res.status_code == 200
    assert b"trade_signals_total" in res.content

def test_record_signal_and_metrics():
    client.post("/signal", params={"type": "Buy"})
    client.post("/signal", params={"type": "Sell"})
    res = client.get("/metrics")
    assert b'trade_signals_total' in res.content
    assert b'type="Buy"' in res.content
    assert b'type="Sell"' in res.content

def test_record_executed_and_metrics():
    client.post("/executed")
    res = client.get("/metrics")
    assert b"trades_executed_total" in res.content

def test_update_drawdown_and_metrics():
    client.post("/drawdown", params={"value": 0.05})
    res = client.get("/metrics")
    assert b"current_drawdown" in res.content
