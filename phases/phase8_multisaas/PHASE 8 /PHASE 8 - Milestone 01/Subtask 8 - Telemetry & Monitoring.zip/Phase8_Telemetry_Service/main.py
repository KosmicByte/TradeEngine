from fastapi import FastAPI, HTTPException
from prometheus_client import Counter, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

app = FastAPI(title="Telemetry Service")

# Prometheus metrics
trade_signal_counter = Counter("trade_signals_total", "Total trade signals generated", ["type"])
trade_executed_counter = Counter("trades_executed_total", "Total trades executed")
drawdown_gauge = Gauge("current_drawdown", "Current drawdown percent")

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

@app.post("/signal")
def record_signal(type: str):
    trade_signal_counter.labels(type=type).inc()
    return {"status": "ok"}

@app.post("/executed")
def record_trade():
    trade_executed_counter.inc()
    return {"status": "ok"}

@app.post("/drawdown")
def update_drawdown(value: float):
    try:
        drawdown_gauge.set(value)
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
