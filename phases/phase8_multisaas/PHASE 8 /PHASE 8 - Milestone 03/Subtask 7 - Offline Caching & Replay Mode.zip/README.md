# Subtask 7: Offline Caching & Replay Mode

This subtask adds offline caching of the last 20 signals and a Replay screen:

- `lib/cache_service.dart`: Caching and retrieval using SharedPreferences
- `lib/replay_screen.dart`: UI to display and clear history
- Updated `lib/main.dart` with History tab
- `test/cache_service_test.dart`: Unit test for cache service
- CI workflow in `.github/workflows/flutter_cache_ci.yml`
