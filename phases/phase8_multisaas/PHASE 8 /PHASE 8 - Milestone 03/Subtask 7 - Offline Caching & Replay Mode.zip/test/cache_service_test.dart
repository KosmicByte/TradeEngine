import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/cache_service.dart';

void main() {
  test('CacheService saves and retrieves history', () async {
    final cache = CacheService();
    final signal = {
      'prediction': 'Buy',
      'confidence': 0.9,
      'timestamp': DateTime.now().millisecondsSinceEpoch
    };
    await cache.clearHistory();
    await cache.saveSignal(signal);
    final hist = await cache.getHistory();
    expect(hist.isNotEmpty, true);
    expect(hist.last['prediction'], 'Buy');
  });
}
