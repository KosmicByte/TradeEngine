import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class CacheService {
  static const _historyKey = 'signal_history';

  Future<void> saveSignal(Map<String, dynamic> signal) async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList(_historyKey) ?? [];
    history.add(jsonEncode(signal));
    // Keep only last 20 entries
    final trimmed = history.length > 20 ? history.sublist(history.length - 20) : history;
    await prefs.setStringList(_historyKey, trimmed);
  }

  Future<List<Map<String, dynamic>>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList(_historyKey) ?? [];
    return history.map((e) => jsonDecode(e) as Map<String, dynamic>).toList();
  }

  Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_historyKey);
  }
}
