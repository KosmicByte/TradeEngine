import 'package:flutter/material.dart';
import 'auth_service.dart';
import 'login_page.dart';
import 'signal_screen.dart';
import 'position_screen.dart';
import 'strategy_screen.dart';
import 'replay_screen.dart';

void main() {
  runApp(TradingCompanionApp());
}

class TradingCompanionApp extends StatefulWidget {
  @override
  _TradingCompanionAppState createState() => _TradingCompanionAppState();
}

class _TradingCompanionAppState extends State<TradingCompanionApp> {
  final AuthService _auth = AuthService();
  String? _apiKey;
  bool _initialized = false;
  @override
  void initState() {
    super.initState();
    _auth.getApiKey().then((key) {
      setState(() { _apiKey = key; _initialized = true; });
    });
  }

  void _onLogin() => setState(() { _apiKey = 'set'; });

  @override
  Widget build(BuildContext context) {
    if (!_initialized) return MaterialApp(home: Scaffold(body: Center(child: CircularProgressIndicator())));
    if (_apiKey == null) return MaterialApp(home: LoginPage(onLoginSuccess: _onLogin));
    return MaterialApp(
      title: 'Trading Companion',
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    SignalScreen(),
    PositionScreen(),
    StrategyScreen(),
    ReplayScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() { _selectedIndex = index; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Trading Companion')),
      body: _widgetOptions[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Signal'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Positions'),
          BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'Strategies'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
