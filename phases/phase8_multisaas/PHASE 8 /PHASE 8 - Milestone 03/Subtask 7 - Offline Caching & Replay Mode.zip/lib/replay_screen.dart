import 'package:flutter/material.dart';
import 'cache_service.dart';

class ReplayScreen extends StatefulWidget {
  const ReplayScreen({Key? key}) : super(key: key);

  @override
  _ReplayScreenState createState() => _ReplayScreenState();
}

class _ReplayScreenState extends State<ReplayScreen> {
  final CacheService _cache = CacheService();
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() async {
    final data = await _cache.getHistory();
    setState(() {
      _history = data.reversed.toList();
    });
  }

  void _clearHistory() async {
    await _cache.clearHistory();
    setState(() {
      _history = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Signal History'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: _clearHistory,
          )
        ],
      ),
      body: _history.isEmpty
          ? Center(child: Text('No history available'))
          : ListView.builder(
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final sig = _history[index];
                return ListTile(
                  title: Text(sig['prediction'] ?? 'Unknown'),
                  subtitle: Text('Confidence: ${(sig['confidence']*100).toStringAsFixed(1)}%'),
                  trailing: Text(DateTime.fromMillisecondsSinceEpoch(sig['timestamp'].toInt()).toLocal().toString()),
                );
              },
            ),
    );
  }
}
