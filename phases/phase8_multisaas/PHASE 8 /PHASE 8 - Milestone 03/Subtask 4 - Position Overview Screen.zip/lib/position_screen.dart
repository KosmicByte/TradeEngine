import 'package:flutter/material.dart';

class PositionScreen extends StatelessWidget {
  final List<Map<String, dynamic>> positions = [
    {
      'symbol': 'NIFTY 17500 CE',
      'entry': 150.0,
      'current': 165.0,
      'pnl': 750.0  // (165-150)*50 lot
    },
    // Add more positions
  ];

  @override
  Widget build(BuildContext context) {
    double totalPnl = positions.fold(0.0, (sum, pos) => sum + pos['pnl']);
    return Scaffold(
      appBar: AppBar(title: Text('Positions & P&L')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Total P&L: ₹${totalPnl.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: positions.length,
                itemBuilder: (context, index) {
                  final pos = positions[index];
                  return Card(
                    child: ListTile(
                      title: Text(pos['symbol']),
                      subtitle: Text('Entry: ₹${pos['entry']}  Current: ₹${pos['current']}'),
                      trailing: Text(
                        '₹${pos['pnl'].toStringAsFixed(2)}',
                        style: TextStyle(
                          color: pos['pnl'] >= 0 ? Colors.green : Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
