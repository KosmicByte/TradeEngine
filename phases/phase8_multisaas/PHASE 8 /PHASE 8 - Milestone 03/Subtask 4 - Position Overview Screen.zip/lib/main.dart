import 'package:flutter/material.dart';
import 'signal_screen.dart';
import 'position_screen.dart';
import 'auth_service.dart';
import 'login_page.dart';

void main() {
  runApp(TradingCompanionApp());
}

class TradingCompanionApp extends StatefulWidget {
  @override
  _TradingCompanionAppState createState() => _TradingCompanionAppState();
}

class _TradingCompanionAppState extends State<TradingCompanionApp> {
  final AuthService _auth = AuthService();
  String? _apiKey;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _checkLogin();
  }

  void _checkLogin() async {
    String? key = await _auth.getApiKey();
    setState(() { _apiKey = key; _initialized = true; });
  }

  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    SignalScreen(),
    PositionScreen(),
  ];

  void _onLogin() {
    setState(() { _apiKey = 'set'; });
  }

  void _onItemTapped(int index) {
    setState(() { _selectedIndex = index; });
  }

  @override
  Widget build(BuildContext context) {
    if(!_initialized) {
      return MaterialApp(home: Scaffold(body: Center(child: CircularProgressIndicator())));
    }
    if(_apiKey == null) {
      return MaterialApp(home: LoginPage(onLoginSuccess: _onLogin));
    }
    return MaterialApp(
      title: 'Trading Companion',
      home: Scaffold(
        appBar: AppBar(title: Text('Trading Companion')),
        body: _widgetOptions.elementAt(_selectedIndex),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: 'Signal'),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Positions'),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
