# Subtask 4: P&L & Position Overview Screen

This subtask adds a PositionScreen to the Flutter app, showing:
- Total P&L from active positions
- List of open positions with PnL color-coded

## Files
- lib/position_screen.dart
- lib/main.dart updated with BottomNavigationBar
- test/position_screen_test.dart
- CI workflow in .github/workflows/flutter_position_ci.yml
