import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/main.dart';

void main() {
  testWidgets('Bottom navigation switches screens', (WidgetTester tester) async {
    await tester.pumpWidget(TradingCompanionApp());
    expect(find.text('Latest Signal:'), findsOneWidget);
    // Tap on Positions tab
    await tester.tap(find.text('Positions'));
    await tester.pump();
    expect(find.text('Total P&L:'), findsOneWidget);
  });
}
