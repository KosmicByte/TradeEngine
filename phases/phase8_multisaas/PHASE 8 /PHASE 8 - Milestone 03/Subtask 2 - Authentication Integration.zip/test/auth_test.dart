import 'package:flutter_test/flutter_test.dart';
import 'package:trading_companion/auth_service.dart';

void main() {
  test('AuthService saves and reads API key', () async {
    final auth = AuthService();
    await auth.saveApiKey('testkey');
    final key = await auth.getApiKey();
    expect(key, 'testkey');
    await auth.deleteApiKey();
    final deleted = await auth.getApiKey();
    expect(deleted, null);
  });
}
