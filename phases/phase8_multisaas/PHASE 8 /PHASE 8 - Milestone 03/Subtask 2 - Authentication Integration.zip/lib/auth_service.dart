import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthService {
  final _storage = FlutterSecureStorage();
  static const _keyApiKey = 'api_key';

  Future<void> saveApiKey(String apiKey) async {
    await _storage.write(key: _keyApiKey, value: apiKey);
  }

  Future<String?> getApiKey() async {
    return await _storage.read(key: _keyApiKey);
  }

  Future<void> deleteApiKey() async {
    await _storage.delete(key: _keyApiKey);
  }
}
