import 'package:flutter/material.dart';
import 'login_page.dart';
import 'auth_service.dart';
import 'home_page.dart';

void main() {
  runApp(TradingCompanionApp());
}

class TradingCompanionApp extends StatefulWidget {
  @override
  _TradingCompanionAppState createState() => _TradingCompanionAppState();
}

class _TradingCompanionAppState extends State<TradingCompanionApp> {
  final AuthService _auth = AuthService();
  String? _apiKey;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _checkLogin();
  }

  void _checkLogin() async {
    String? key = await _auth.getApiKey();
    setState(() { _apiKey = key; _initialized = true; });
  }

  void _onLogin() {
    setState(() { _apiKey = 'set'; });
  }

  @override
  Widget build(BuildContext context) {
    if(!_initialized) {
      return MaterialApp(home: Scaffold(body: Center(child: CircularProgressIndicator())));
    }
    if(_apiKey == null) {
      return MaterialApp(home: LoginPage(onLoginSuccess: _onLogin));
    }
    return MaterialApp(
      title: 'Trading Companion',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}
